from django.apps import AppConfig
class PollsConfig(AppConfig):
    default_app_config ='D:\djangoProject\mysite\mysite\settings.py'